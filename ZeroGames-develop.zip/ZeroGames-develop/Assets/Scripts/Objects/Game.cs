﻿using UnityEngine;

public class Game : ScriptableObject
{
    
}
