﻿using UnityEngine;

public class Player : ScriptableObject {
    private Stable _stable;
}
