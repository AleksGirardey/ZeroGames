using UnityEngine;

public class Stable : ScriptableObject {
    
}